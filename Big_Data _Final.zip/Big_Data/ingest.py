import pandas as pd
from sqlalchemy import create_engine
import os
from unidecode import unidecode
import logging
import argparse

# ===============================
# CONFIG
# ===============================
DB_USER = "admin"
DB_PASS = "admin123"
DB_HOST = "localhost"
DB_PORT = "5432"
DB_NAME = "kaggle_db"

# Kaggle file
FILE_PATH = "GoodReads_100k_books.csv"

# ===============================
# MAIN FUNCTION FOR PIPELINE
# ===============================
def run(date=None):
    logging.info("[INGEST] Starting ingest step...")

    # เชื่อม PostgreSQL
    engine = create_engine(
        f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )

    # ตรวจสอบไฟล์ก่อนอ่าน
    if not os.path.exists(FILE_PATH):
        raise FileNotFoundError(f"[INGEST] File not found: {FILE_PATH}")

    table_name = os.path.basename(FILE_PATH).split('.')[0].lower()
    logging.info(f"[INGEST] Reading file: {FILE_PATH}")

    # อ่าน CSV
    df = pd.read_csv(FILE_PATH, encoding="utf-8-sig", header=0)
    df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

    # Transliteration
    for col in ["title", "author", "desc"]:
        if col in df.columns:
            logging.info(f"[INGEST] Transliteration column: {col}")
            df[col] = df[col].apply(
                lambda x: unidecode(str(x)) if pd.notnull(x) else x
            )

    # Load → PostgreSQL schema raw_data
    logging.info(f"[INGEST] Loading into raw_data.{table_name} ...")

    df.to_sql(
        table_name,
        engine,
        schema="raw_data",
        if_exists="replace",
        index=False
    )

    logging.info("[INGEST] Done. Data loaded successfully ✓")


# ===============================
# RUN WHEN CALLED DIRECTLY
# ===============================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s"
    )

    run(date=args.date)
