#!/usr/bin/env python3
# run_pipeline.py (WINDOWS VERSION)

import argparse
import logging
import sys
import time
from pathlib import Path
import subprocess

# แนะนำให้สร้างโฟลเดอร์นี้ก่อน
LOCKFILE = Path("D:/Big_Data/temp/run_pipeline.lock")

# =========================
# LOCKFILE FUNCTIONS
# =========================
def acquire_lock():
    if LOCKFILE.exists():
        raise RuntimeError(
            f"Lockfile {LOCKFILE} exists — another run is in progress."
        )
    LOCKFILE.write_text(str(time.time()))

def release_lock():
    try:
        if LOCKFILE.exists():
            LOCKFILE.unlink()
    except Exception:
        pass

# =========================
# RETRY WRAPPER
# =========================
def call_with_retry(func, retries=2, backoff=5, *args, **kwargs):
    last_exc = None
    for attempt in range(1, retries + 2):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            last_exc = e
            logging.exception(
                f"[Retry] Attempt {attempt} failed for {func.__name__}: {e}"
            )
            if attempt <= retries:
                time.sleep(backoff * attempt)
    raise last_exc

# =========================
# RUN MODULE OR SUBPROCESS
# =========================
def run_module_or_subprocess(module_name, date_arg):
    try:
        mod = __import__(module_name, fromlist=["run"])
        if hasattr(mod, "run"):
            logging.info(f"Running {module_name}.run(date={date_arg}) as module")
            return mod.run(date=date_arg)
        else:
            raise ImportError("Module has no run()")
    except Exception as e:
        logging.warning(
            f"Failed to run as module: {module_name}. Error: {e}. Using subprocess."
        )
        cmd = [sys.executable, f"{module_name}.py"]
        if date_arg:
            cmd += ["--date", date_arg]
        subprocess.check_call(cmd)

# =========================
# MAIN PIPELINE
# =========================
def main():
    parser = argparse.ArgumentParser(description="Full pipeline: ingest → transform → publish")
    parser.add_argument("--date", default=None)
    parser.add_argument("--mode", choices=["full", "incremental"], default="incremental")
    parser.add_argument("--no-lock", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s"
    )

    try:
        if not args.no_lock:
            acquire_lock()

        logging.info("===== PIPELINE STARTED =====")

        # INGEST
        call_with_retry(lambda: run_module_or_subprocess("ingest", args.date))

        # TRANSFORM
        call_with_retry(lambda: run_module_or_subprocess("transform", args.date))

        # PUBLISH
        call_with_retry(lambda: run_module_or_subprocess("publish", args.date))

        logging.info("===== PIPELINE FINISHED SUCCESSFULLY =====")

    except Exception as e:
        logging.exception("Pipeline FAILED!")
        sys.exit(1)

    finally:
        if not args.no_lock:
            release_lock()


if __name__ == "__main__":
    main()
