import pandas as pd
from sqlalchemy import create_engine
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import time
from datetime import datetime

# ------------------------------
# CONFIG
# ------------------------------
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "kaggle_db",
    "user": "admin",
    "password": "admin123"
}

SPREADSHEET_NAME = "GoodRead100K"
CHUNK_SIZE = 20000
WORKSHEET_NAME = "GoodRead100K"  # ชื่อชีทใน Google Sheets


# ------------------------------
# LOGGING HELPER
# ------------------------------
def log(msg):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] [INFO] [PUBLISH] {msg}")


# ------------------------------
# LOAD DATA FROM POSTGRESQL USING SQLALCHEMY
# ------------------------------
def load_data():
    log("Loading data from PostgreSQL...")

    # สร้าง SQLAlchemy engine
    engine = create_engine(
        f"postgresql+psycopg2://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
        f"@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['dbname']}"
    )

    df = pd.read_sql("SELECT * FROM production.goodreads_clean;", engine)

    log(f"Loaded {len(df):,} rows, {len(df.columns)} columns")
    return df


# ------------------------------
# SPLIT INTO CHUNKS
# ------------------------------
def chunker(seq, size):
    for pos in range(0, len(seq), size):
        yield seq[pos:pos + size]


# ------------------------------
# MAIN UPLOAD TO GOOGLE SHEETS
# ------------------------------
def publish():
    df = load_data()

    # Google Sheets Auth
    scope = ["https://spreadsheets.google.com/feeds",
             "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name(
        "goodread100k-80e9fc5239d3.json", scope)
    client = gspread.authorize(creds)

    spreadsheet = client.open(SPREADSHEET_NAME)
    sheet = spreadsheet.worksheet(WORKSHEET_NAME)

    # Clear old data
    log("Clearing sheet...")
    sheet.clear()

    # Upload header
    header = df.columns.tolist()
    sheet.update([header], "A1")  # <-- positional arguments: values, range

    log(f"Uploading using chunks of {CHUNK_SIZE} rows...")

    rows = df.values.tolist()
    start_row = 2
    chunk_index = 1

    for chunk in chunker(rows, CHUNK_SIZE):
        end_row = start_row + len(chunk) - 1
        range_str = f"A{start_row}"

        log(f"Uploading chunk {chunk_index} ({len(chunk)} rows)...")

        sheet.update(chunk, range_str)  # <-- positional arguments: values, range

        start_row = end_row + 1
        chunk_index += 1

        time.sleep(1.0)  # ป้องกันการโดน rate limit

    log("Upload completed successfully!")


if __name__ == "__main__":
    publish()
