import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text
from unidecode import unidecode
import logging
import argparse

# ===============================
# CONFIG
# ===============================
DB_CONN = "postgresql://admin:admin123@localhost:5432/kaggle_db"


# ===============================
# MAIN FUNCTION
# ===============================
def run(date=None):
    logging.info("[TRANSFORM] Starting transform step...")

    try:
        engine = create_engine(DB_CONN, pool_pre_ping=True)

        # Load raw data
        logging.info("[TRANSFORM] Loading raw_data.goodreads_100k_books ...")
        df = pd.read_sql(
            text("SELECT * FROM raw_data.goodreads_100k_books"),
            engine
        )

        # ------------------------------
        # CLEANING
        # ------------------------------
        logging.info("[TRANSFORM] Cleaning numeric columns...")
        numeric_cols = ["pages", "rating", "reviews", "totalratings"]
        df[numeric_cols] = df[numeric_cols].apply(
            lambda s: pd.to_numeric(s, errors="coerce")
        )

        df["rating"] = df["rating"].fillna(df["rating"].mean())
        df["reviews"] = df["reviews"].fillna(0)
        df["pages"] = df["pages"].fillna(df["pages"].median())
        df["totalratings"] = df["totalratings"].fillna(0)

        df["title"] = df["title"].fillna("Unknown Title")
        df["author"] = df["author"].fillna("Unknown Author")
        df["desc"] = df["desc"].fillna("")

        # 🔥 REMOVE BOOKS WITH pages = 0
        logging.info("[TRANSFORM] Removing rows where pages = 0 ...")
        before = len(df)
        df = df[df["pages"] != 0]
        after = len(df)
        logging.info(f"[TRANSFORM] Removed {before - after} rows with pages = 0")

        # ------------------------------
        # Transliteration
        # ------------------------------
        logging.info("[TRANSFORM] Transliteration (title, author, desc)...")
        for col in ["title", "author", "desc"]:
            if col in df.columns:
                df[col] = df[col].apply(
                    lambda x: unidecode(str(x)) if pd.notnull(x) else x
                )

        # ------------------------------
        # FEATURE ENGINEERING
        # ------------------------------
        logging.info("[TRANSFORM] Generating features...")
        df["pop_score"] = df["rating"] * df["totalratings"]

        df["length_category"] = pd.cut(
            df["pages"],
            bins=[0, 150, 350, 2000, 100000],
            labels=["Short", "Medium", "Long", "Extra Long"],
            include_lowest=True
        )

        df["main_genre"] = df["genre"].apply(
            lambda x: str(x).split(",")[0].strip() if pd.notnull(x) else "Unknown"
        )

        # ------------------------------
        # DROP UNUSED COLUMNS
        # ------------------------------
        logging.info("[TRANSFORM] Dropping unused columns...")
        cols_to_drop = ["link", "img", "genre"]
        df = df.drop(columns=[c for c in cols_to_drop if c in df.columns])

        # ------------------------------
        # AGGREGATION
        # ------------------------------
        logging.info("[TRANSFORM] Aggregating genre summary...")
        genre_summary = df.groupby("main_genre").agg({
            "rating": "mean",
            "pages": "mean",
            "totalratings": "sum"
        }).reset_index()

        # ------------------------------
        # SAVE TO production SCHEMA
        # ------------------------------
        logging.info("[TRANSFORM] Saving results to production schema...")

        df.to_sql(
            "goodreads_clean",
            engine,
            schema="production",
            if_exists="replace",
            index=False
        )

        genre_summary.to_sql(
            "goodreads_genre_summary",
            engine,
            schema="production",
            if_exists="replace",
            index=False
        )

        logging.info("[TRANSFORM] Transform complete ✓")

    except Exception as e:
        logging.exception("[TRANSFORM] ERROR:")
        raise e  # ให้ pipeline จับ error ได้


# ===============================
# RUN WHEN CALLED DIRECTLY
# ===============================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s"
    )

    run(date=args.date)
